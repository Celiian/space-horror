using UnityEngine;

namespace BehaviorTree
{
    public abstract class Tree : MonoBehaviour
    {
        public Node _root = null;

        protected void Start()
        {
            _root = SetupTree();
        }

        private void Update()
        {
            if(_root == null) return;
            _root.Evaluate();
        }

        private void LateUpdate()
        {
            if(_root == null) return;
            _root.EvaluateLateUpdate();
        }

        private void FixedUpdate()
        {
            if(_root == null) return;
            _root.EvaluateFixedUpdate();
        }

        protected abstract Node SetupTree();

    }
}
