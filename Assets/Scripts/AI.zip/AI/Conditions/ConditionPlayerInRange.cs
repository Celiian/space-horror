using BehaviorTree;
using UnityEngine;

public class ConditionPlayerInRange : Node
{
    private Transform transform;

    public ConditionPlayerInRange(Transform transform)
    {
        this.transform = transform;
    }
}
    