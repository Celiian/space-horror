using System.Collections.Generic;
using BehaviorTree;
using UnityEngine;
using Tree = BehaviorTree.Tree;

public class ActionRandomPatrol : Node
{
    private Transform transform;
    private List<PathNode> pathWaypoints;
    private int currentWaypointIndex = 0;
    
    public ActionRandomPatrol(Transform transform){
        this.transform = transform;
        PathNode startNode = PathFinding.Instance.FindNodeCloseToPosition(transform.position);
        pathWaypoints = PathFinding.Instance.GetRandomPath(start: startNode);
    }

    public override NodeState Evaluate()
    {
        SetTopParentData("target", pathWaypoints[currentWaypointIndex].transform);
        currentWaypointIndex ++;

        if(currentWaypointIndex == pathWaypoints.Count - 1){
            PathNode currentWaypoint = pathWaypoints[currentWaypointIndex];
            pathWaypoints = PathFinding.Instance.GetRandomPath(start: currentWaypoint);
            currentWaypointIndex = 0;
        }

        return NodeState.SUCCESS;
    }
}
