using System.Collections.Generic;
using BehaviorTree;
using UnityEngine;
using Tree = BehaviorTree.Tree;


public class ZombieBT : Tree
{
    [SerializeField]
    private ZombieStatsSO stats;
    private Rigidbody2D rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    protected override Node SetupTree()
    {   
        _root = new Selector(
            new List<Node>{
                new SequenceOnce( new List<Node>{
                    new SetData(stats.GetStats()),
                    new SetData(new Dictionary<string, object>{
                        {"target", null}
                    }),
                }),
                new Sequence( new List<Node>{
                    new CheckNotNull("target"),
                    new ActionMoveToTarget(transform, rb),
                }),
                new ActionRandomPatrol(transform),
            }
        );
        return _root;
    }

}
